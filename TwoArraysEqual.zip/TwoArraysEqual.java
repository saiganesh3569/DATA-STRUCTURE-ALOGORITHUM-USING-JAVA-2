import java.util.Arrays;

public class TwoArraysEqual {
	 public static boolean areEqual(int arr1[], int arr2[])
	    {
	        int A = arr1.length;
	        int B = arr2.length;
	        if (A != B)
	            return false;
	        Arrays.sort(arr1);
	        Arrays.sort(arr2);
	        for (int i = 0; i < A; i++)
	            if (arr1[i] != arr2[i])
	                return false;
	        return true;
	    }
	    public static void main(String[] args)
	    {
	        int arr1[] = { 1, 2, 5  };
	        int arr2[] = { 2, 4, 15 };
	 
	        // Function call
	        if (areEqual(arr1, arr2))
	            System.out.println("1");
	        else
	            System.out.println("0");
	    }
}
