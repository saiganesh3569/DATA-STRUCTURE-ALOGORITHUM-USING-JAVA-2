
public class SubArray {
	 int subArraySum(int arr[], int n, int s)
{
 int curr_sum, i, j;
 for (i = 0; i < n; i++) 
 {
     curr_sum = arr[i];
     for (j = i + 1; j <= n; j++) 
     {
         if (curr_sum == s) 
         {
             int p = j - 1;
             System.out.println(
              "Sum found between indexes " + 
               i + " and " + p);
             return 1;
         }
         if (curr_sum > s || j == n)
             break;
         curr_sum = curr_sum + arr[j];
     }
 }
 System.out.println("No subarray found");
 return 0;
}
	 public static void main(String[] args)
	    {
	        SubArray arraysum =  new SubArray();
	        int arr[] = {1, 2, 3, 7, 5};
	        int n = arr.length;
	        int s = 12;
	        arraysum.subArraySum(arr, n, s);
	    }
}
