import java.util.Arrays;

public class MinimizeSum {
	  static long minValue(int A[], int B[], int N)
	    {
	        Arrays.sort(A);
	        Arrays.sort(B);
	        long result = 0;
	        for (int i = 0; i < N; i++)
	            result += (A[i] * B[N - i - 1]);
	        return result;
	    }
	    public static void main(String[] args)
	    {
	        int A[] = { 6, 1, 9, 5, 4 };
	        int B[] = { 3, 4, 8, 2, 4 };
	        int N = A.length;
	        
	        System.out.println(minValue(A, B, N));
	    }
}
