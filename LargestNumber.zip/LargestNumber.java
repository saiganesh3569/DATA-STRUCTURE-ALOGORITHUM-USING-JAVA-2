
public class LargestNumber {
	 static void findLargest(int N, int S)
	    {
	        if (S == 0)
	        {
	            System.out.print(N == 1 ? "Largest number is 0" : "Not possible"); 
	            
	            return ;
	        }
	        if (S > 9*N)
	        {
	            System.out.println("Not possible");
	            return ;
	        }
	        int[] res = new int[N];
	        for (int i=0; i<N; i++)
	        {
	        	  if (S >= 9)
	              {
	                  res[i] = 9;
	                  S -= 9;
	              }
	              else
	              {
	                  res[i] = S;
	                  S = 0;
	              }
	          }
	          System.out.print("Largest number is ");
	          for (int i=0; i<N; i++)
	              System.out.print(res[i]);
	      }
	      public static void main (String[] args) 
	      {
	          int S = 20, N = 3;
	          findLargest(N, S);
	      }	
	        
}
