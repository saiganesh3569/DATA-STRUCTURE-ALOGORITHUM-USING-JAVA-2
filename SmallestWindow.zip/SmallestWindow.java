
public class SmallestWindow {
	 static String Minimum_Window(char[] S, char[] T)
	    {
	        int m[] = new int[256];
	        int ans = Integer.MAX_VALUE;
	        int start = 0;
	        int count = 0;
	        for (int i = 0; i < T.length; i++) {
	            if (m[T[i]] == 0)
	                count++;
	            m[T[i]]++;
	        }
	        int i = 0;
	        int j = 0;
	        while (j < S.length) {
	            m[S[j]]--;
	     if (m[S[j]] == 0)
	        count--;
	    if (count == 0) {
	    while (count == 0) {
	   if (ans > j - i + 1) {
	ans = Math.min(ans, j - i + 1);
 start = i;
 }
	 m[S[i]]++;
	 if (m[S[i]] > 0)
 count++;
	     i++;
	  }
  }
	    j++;
	 }
 if (ans != Integer.MAX_VALUE)
 return String.valueOf(S).substring(start, ans + start);
    else
	   return "-1";
	      }
 public static void main(String[] args) {
	    String S = "Time to practice";
	    String T = "toc";
	   
	System.out.print(Minimum_Window(S.toCharArray(), T.toCharArray()));
	      }
         }
	
