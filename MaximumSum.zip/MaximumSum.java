import java.util.Vector;

public class MaximumSum {
	 static int findSum(Vector<Integer> arr)
	    {
	        int sum = 0;
	        for (int i : arr)
	            sum += i;
	        return sum;
	    }
	    static void printMaxSumIs(int[] arr, int n)
	    {
	        @SuppressWarnings("unchecked")
	        Vector<Integer>[] L = new Vector[n];
	 
	        for (int i = 0; i < n; i++)
	            L[i] = new Vector<>();
	        L[0].add(arr[0]);
	        for (int i = 1; i < n; i++) {
	            for (int j = 0; j < i; j++) {
	            	 if ((arr[i] > arr[j])
	                         && (findSum(L[i]) < findSum(L[j]))) {
	                         for (int k : L[j])
	                             if (!L[i].contains(k))
	                                 L[i].add(k);
	                     }
	                 }
	                 L[i].add(arr[i]);
	             }
	      
	             Vector<Integer> res = new Vector<>(L[0]);
	             for (Vector<Integer> x : L)
	                 if (findSum(x) > findSum(res))
	                     res = x;
	             for (int i : res)
	                 System.out.print(i + " ");
	             System.out.println();
	         }
	    public static void main(String[] args)
	    {
	        int[] arr = {1, 101, 2, 3, 100, 4, 5};
	        int n = arr.length;
	        printMaxSumIs(arr, n);
	    }
	            }

